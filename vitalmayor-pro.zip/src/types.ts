export interface Medication {
  name: string;
  subtitle: string;
  pauta: string;
  comida: string;
  riesgo: string;
  contraindicaciones: string[];
}

export interface Interaction {
  medication: string;
  severity: "low" | "medium" | "high";
  explanation: string;
}

export interface AnalysisResult {
  name: string;
  subtitle?: string;
  safe: boolean;
  contraindicated: boolean;
  riskSeverity: "low" | "medium" | "high";
  riskExplanation: string;
  pauta: string;
  comida: string;
  interacciones: Interaction[];
  consejoCuidador: string;
  isAiOptimized?: boolean; // True if returned by server Gemini
}

export interface PatientProfile {
  name: string;
  diagnosis: string; // "Hipertensión Arterial" | "Diabetes Mellitus" | "Artrosis" | "Insuficiencia Renal" | "Ninguno"
  selectedMeds: string[];
}

export interface HistoryEntry {
  id: string;
  timestamp: string;
  patientName: string;
  diagnosis: string;
  medicationName: string;
  result: AnalysisResult;
}
