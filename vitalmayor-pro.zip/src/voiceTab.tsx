import React, { useState } from "react";
import { Mic, MicOff, AlertCircle, HelpCircle, Sparkles, CheckCircle, Volume2 } from "lucide-react";

interface VoiceTabProps {
  onVoiceResult: (transcript: string) => void;
}

export default function VoiceTab({ onVoiceResult }: VoiceTabProps) {
  const [isListening, setIsListening] = useState(false);
  const [resultText, setResultText] = useState("");
  const [errorText, setErrorText] = useState("");

  const startSpeechRecognition = () => {
    setErrorText("");
    setResultText("");

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setErrorText("El reconocimiento de voz de la Web API no es compatible con el navegador web actual.");
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.lang = "es-ES";
      recognition.interimResults = false;
      recognition.maxAlternatives = 1;

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setResultText(transcript);
        setIsListening(false);
        // Fire result
        setTimeout(() => {
          onVoiceResult(transcript);
          setResultText("");
        }, 1200);
      };

      recognition.onerror = (event: any) => {
        console.error("Speech error", event.error);
        setIsListening(false);
        if (event.error === "not-allowed") {
          setErrorText("Permiso de micrófono denegado. Conceda permiso o simule hablar abajo.");
        } else {
          setErrorText("Error al capturar la voz. Por favor, hable alto y claro.");
        }
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.start();
    } catch (e: any) {
      console.error(e);
      setIsListening(false);
      setErrorText("Error al iniciar el módulo de dictado.");
    }
  };

  // Simulates talking inside sandbox environment
  const handleSimulateVoice = (phrase: string) => {
    setIsListening(true);
    setResultText(`Escuchando... "${phrase}"`);
    setErrorText("");
    setTimeout(() => {
      setIsListening(false);
      onVoiceResult(phrase);
      setResultText("");
    }, 1500);
  };

  return (
    <div className="space-y-6">
      {/* Microphone interface */}
      <section className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100/80 text-center transition-all duration-300">
        <div className="flex flex-col items-center p-8">
          <button
            id="mic-pulse-button"
            onClick={startSpeechRecognition}
            disabled={isListening}
            className={`w-24 h-24 rounded-full flex items-center justify-center transition-all relative ${
              isListening
                ? "bg-rose-500 text-white animate-pulse shadow-rose-200 shadow-2xl ring-4 ring-rose-105"
                : "bg-teal-50 text-teal-700 hover:bg-teal-100/80 active:scale-95 shadow-lg border border-teal-100"
            }`}
          >
            {isListening ? (
              <Volume2 className="w-10 h-10 animate-fade-in-out" />
            ) : (
              <Mic className="w-10 h-10 fill-teal-700/10" />
            )}
            
            {/* Visual sound ripples */}
            {isListening && (
              <>
                <span className="absolute inline-flex h-full w-full rounded-full bg-rose-450 opacity-40 animate-ping -z-10" />
                <span className="absolute inline-flex h-[130%] w-[130%] rounded-full bg-rose-400 opacity-20 animate-ping -z-15" />
              </>
            )}
          </button>
          
          <h2 className="text-teal-900 text-lg font-bold mt-6 mb-1">
            {isListening ? "Escuchando... hable ahora" : "Búsqueda Rápida por Voz"}
          </h2>
          <p className="text-xs text-slate-500 max-w-sm mx-auto font-medium leading-relaxed mb-4">
            {isListening
              ? "Diga por ejemplo 'Omeprazol' o 'Ibuprofeno' de forma clara y pausada."
              : "Presione el botón para dictar el nombre del medicamento a evaluar."}
          </p>

          {resultText && (
            <div className="flex items-center gap-1.5 px-4 py-2 bg-teal-50 border border-teal-100 rounded-xl text-teal-800 font-bold text-sm animate-pulse mb-2">
              <CheckCircle className="w-4 h-4 text-teal-600" />
              {resultText}
            </div>
          )}

          {errorText && (
            <div className="flex items-start gap-2 text-rose-800 text-xs text-left p-3.5 bg-rose-500/10 border border-rose-200/40 rounded-xl max-w-md mx-auto">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div className="font-semibold leading-relaxed">{errorText}</div>
            </div>
          )}
        </div>
      </section>

      {/* Voice Simulation Prompts */}
      <section className="bg-slate-50 border border-slate-200 rounded-2xl p-6 transition-all duration-300">
        <h3 className="flex items-center gap-1.5 text-slate-800 text-sm font-bold mb-2">
          <Sparkles className="w-4 h-4 text-teal-600 fill-teal-100/10" />
          Probeta de Simulación Vocofónica (Sandbox Testing)
        </h3>
        <p className="text-[11px] text-slate-500 mb-4 font-medium leading-relaxed">
          Si su navegador web bloquea el micrófono por seguridad de iframe, simule cualquiera de estas peticiones de voz con un solo clic:
        </p>

        <div className="grid grid-cols-2 gap-2">
          {[
            { tag: "Ibuprofeno", subtitle: "Dolores musculares" },
            { tag: "Warfarina", subtitle: "Anticoagulación" },
            { tag: "Omeprazol", subtitle: "Reflujo acidez" },
            { tag: "Losartán", subtitle: "Presión arterial" }
          ].map((item) => (
            <button
              id={`simulate-voice-${item.tag}`}
              key={item.tag}
              onClick={() => handleSimulateVoice(item.tag)}
              className="text-left bg-white border border-slate-200 rounded-xl p-3 hover:border-teal-500 hover:shadow-sm active:scale-[0.98] transition-all flex items-center gap-3 cursor-pointer group"
            >
              <div className="bg-teal-50 text-teal-700 p-2 rounded-lg group-hover:bg-teal-100/80">
                <Mic className="w-4 h-4 fill-teal-700/10" />
              </div>
              <div>
                <p className="text-xs font-bold text-teal-900 group-hover:text-teal-700">"{item.tag}"</p>
                <p className="text-[10px] text-slate-400 font-semibold">{item.subtitle}</p>
              </div>
            </button>
          ))}
        </div>
      </section>
    </div>
  );
}
