import { Medication, AnalysisResult, Interaction } from "./types";

export const clinicalDB: Record<string, Medication> = {
  omeprazol: {
    name: "Omeprazol",
    subtitle: "Protector gástrico para el control de la acidez y reflujo gastroesofágico.",
    pauta: "Tomar 1 cápsula en ayunas, de 30 a 60 minutos antes del desayuno.",
    comida: "Evitar ingerir junto con lácteos de forma inmediata, ya que reducen su absorción.",
    riesgo: "El uso prolongado (años) puede alterar la absorción de vitamina B12 y magnesio.",
    contraindicaciones: []
  },
  losartan: {
    name: "Losartán",
    subtitle: "Antihipertensivo utilizado para el tratamiento de la presión arterial de forma sostenida.",
    pauta: "Tomar 1 comprimido al día, preferentemente a la misma hora para mantener niveles estables.",
    comida: "Puede tomarse con o sin alimentos. Mantenga una hidratación regular.",
    riesgo: "Riesgo de hipotensión severa al ponerse de pie de manera súbita.",
    contraindicaciones: []
  },
  ibuprofeno: {
    name: "Ibuprofeno",
    subtitle: "Antiinflamatorio no esteroideo (AINE) para tratar el dolor moderado e inflamación.",
    pauta: "Tomar con alimentos. Evitar prolongar el uso por más de 5 días seguidos sin indicación médica.",
    comida: "Tomar siempre acompañado de alimentos para proteger la mucosa estomacal.",
    riesgo: "Aumenta la presión arterial, genera retención de líquidos y eleva el riesgo de sangrado digestivo.",
    contraindicaciones: ["Hipertensión Arterial", "Insuficiencia Renal"]
  },
  metformina: {
    name: "Metformina",
    subtitle: "Antidiabético oral para el control de la glucosa en personas con diabetes tipo 2.",
    pauta: "Tomar durante o inmediatamente después de las comidas principales (desayuno/cena).",
    comida: "Ayuda a disminuir las molestias tipo náuseas o diarreas leves al inicio del tratamiento.",
    riesgo: "Riesgo de acidosis láctica en situaciones de deshidratación extrema o insuficiencia renal.",
    contraindicaciones: ["Insuficiencia Renal"]
  },
  atorvastatina: {
    name: "Atorvastatina",
    subtitle: "Lípido modificador (estatina) destinado a reducir el colesterol y riesgo cardiovascular.",
    pauta: "Tomar preferentemente antes de acostarse para coincidir con la síntesis nocturna de colesterol.",
    comida: "Evitar el consumo excesivo de jugo de pomelo de forma simultánea.",
    riesgo: "Riesgo de dolores musculares (miopatía). Avisar si aparece debilidad sin explicación.",
    contraindicaciones: []
  },
  levotiroxina: {
    name: "Levotiroxina",
    subtitle: "Hormona tiroidea para sustituir la deficiencia en casos de hipotiroidismo.",
    pauta: "Tomar en ayunas absolutas con un vaso de agua entera, al menos 45 minutos antes de desayunar.",
    comida: "No tomar con suplementos de calcio, hierro o soya; interfieren severamente en su absorción.",
    riesgo: "No suspender de forma repentina; requiere exámenes de control de TSH de manera habitual.",
    contraindicaciones: []
  },
  enalapril: {
    name: "Enalapril",
    subtitle: "Inhibidor de la ECA utilizado para controlar la presión arterial alta o insuficiencia cardíaca.",
    pauta: "Tomar 1 comprimido al día, a la misma hora habitual. Evitar dosis nocturna tardía.",
    comida: "Puede causar tos seca persistente como efecto secundario común e inofensivo.",
    riesgo: "Riesgo de exceso de potasio si se usan sustitutos de sal de mesa.",
    contraindicaciones: []
  },
  paracetamol: {
    name: "Paracetamol",
    subtitle: "Analgésico contra el dolor leve/moderado y antipirético eficaz contra la fiebre.",
    pauta: "Tomar según indicaciones. Nunca superar los 4 gramos (4000 mg) acumulados en 24 horas.",
    comida: "No sobrecargar el organismo. Es el fármaco de dolor más seguro para pacientes hipertensos.",
    riesgo: "Toxicidad hepática severa por sobredosificación o consumo simultáneo de alcohol.",
    contraindicaciones: []
  },
  furosemida: {
    name: "Furosemida",
    subtitle: "Diurético de asa de alta potencia para reducir edemas y sobrecarga de líquidos.",
    pauta: "Tomar por la mañana al despertar para evitar interrumpir las horas de sueño nocturnas.",
    comida: "Vigila la ingesta de potasio. Puede ser necesario tomar suplementos o alimentos como plátano.",
    riesgo: "Riesgo de deshidratación rápida, calambres y desequilibrios electrolíticos de potasio.",
    contraindicaciones: []
  },
  warfarina: {
    name: "Warfarina",
    subtitle: "Anticoagulante oral para prevenir la formación de coágulos y embolias sanguíneas.",
    pauta: "Tomar rigurosamente a la misma hora del día. Requiere control constante del valor INR.",
    comida: "Mantenga un hábito regular de vegetales de hoja verde (vitamina K) para no desbalancear el efecto.",
    riesgo: "Riesgo severo de hemorragia. Contraindicado combinar con medicamentos como Ibuprofeno.",
    contraindicaciones: []
  }
};

export const medicationsList = [
  "Losartán",
  "Metformina",
  "Omeprazol",
  "Atorvastatina",
  "Levotiroxina",
  "Enalapril",
  "Ibuprofeno",
  "Paracetamol",
  "Furosemida",
  "Warfarina"
];

export const normalizeText = (text: string): string => {
  return text
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "");
};

export const filterMedicationKey = (text: string): string | null => {
  const normalizedText = normalizeText(text);
  const keys = Object.keys(clinicalDB);
  for (const key of keys) {
    if (normalizedText.includes(normalizeText(key))) {
      return key;
    }
  }
  return null;
};

// Generates local AnalysisResult if offline
export function getLocalAnalysis(
  medName: string,
  patientName: string,
  diagnosis: string,
  currentMeds: string[]
): AnalysisResult {
  const key = filterMedicationKey(medName) || medName.toLowerCase();
  const dbItem = clinicalDB[key];

  if (!dbItem) {
    // Return generic safely
    return {
      name: medName,
      subtitle: "Principio activo o marca no listada en base local.",
      safe: true,
      contraindicated: false,
      riskSeverity: "low",
      riskExplanation: "No se encuentra registro detallado de este fármaco en la base local. Por favor, realiza una consulta con conexión de Red o consulta a tu farmacéutico.",
      pauta: "Se sugiere revisar el prospecto médico para la dosificación habitual.",
      comida: "Acompañar con abundante agua.",
      interacciones: [],
      consejoCuidador: "Ante la duda, verifique el empaque y asegúrese de que corresponde a lo prescrito por el médico de cabecera."
    };
  }

  const isContraindicated = dbItem.contraindicaciones.includes(diagnosis);
  const interacciones: Interaction[] = [];

  // Manual drug-drug interaction calculation for high accuracy local fallback
  if (key === "ibuprofeno") {
    const conflicts = currentMeds.map(m => m.toLowerCase());
    if (conflicts.includes("warfarina")) {
      interacciones.push({
        medication: "Warfarina",
        severity: "high",
        explanation: "La combinación dispara drásticamente el riesgo de hemorragia gástrica e interna grave. Evite usar Ibuprofeno si toma anticoagulantes."
      });
    }
    if (conflicts.includes("losartan") || conflicts.includes("enalapril")) {
      interacciones.push({
        medication: conflicts.includes("losartan") ? "Losartán" : "Enalapril",
        severity: "medium",
        explanation: "Los AINEs reducen el efecto terapéutico de los fármacos para la presión arterial y sobrecargan de sobremanera la función de los riñones."
      });
    }
  }

  if (key === "warfarina") {
    const conflicts = currentMeds.map(m => m.toLowerCase());
    if (conflicts.includes("ibuprofeno")) {
      interacciones.push({
        medication: "Ibuprofeno",
        severity: "high",
        explanation: "Peligro crítico de sangrados digestivos de alta severidad. Prefiera usar analgésicos seguros como Paracetamol."
      });
    }
  }

  if (key === "furosemida") {
    const conflicts = currentMeds.map(m => m.toLowerCase());
    if (conflicts.includes("losartan") || conflicts.includes("enalapril")) {
      interacciones.push({
        medication: conflicts.includes("losartan") ? "Losartán" : "Enalapril",
        severity: "medium",
        explanation: "Efecto aditivo que puede provocar hipotensión ortostática (sensación de mareo o desmayo al levantarse)."
      });
    }
  }

  const riskSeverity = isContraindicated ? "high" : interacciones.length > 0 ? "medium" : "low";
  let riskExplanation = isContraindicated
    ? `Este medicamento está contraindicado debido al diagnóstico de ${diagnosis}. ${dbItem.riesgo}`
    : "Sin contraindicaciones directas detectadas con el diagnóstico de este paciente.";

  if (interacciones.length > 0) {
    riskExplanation += ` Se detectaron ${interacciones.length} riesgo(s) de interacción con su tratamiento habitual.`;
  }

  return {
    name: dbItem.name,
    subtitle: dbItem.subtitle,
    safe: !isContraindicated && interacciones.every(i => i.severity !== "high"),
    contraindicated: isContraindicated,
    riskSeverity,
    riskExplanation,
    pauta: dbItem.pauta,
    comida: dbItem.comida,
    interacciones,
    consejoCuidador: `Recuerde vigilar de forma continua el pulso del paciente y su adherencia a los horarios establecidos.`
  };
}
