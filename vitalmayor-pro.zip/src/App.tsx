import React, { useState, useEffect } from "react";
import { Sparkles, Info, Users, ShieldAlert, CheckCircle } from "lucide-react";
import { PatientProfile, AnalysisResult, HistoryEntry } from "./types";
import { getLocalAnalysis } from "./clinicalDB";

import Header from "./components/Header";
import PatientTab from "./components/PatientTab";
import ScannerTab from "./components/ScannerTab";
import VoiceTab from "./voiceTab"; // created directly in src/voiceTab.tsx
import HistoryTab from "./components/HistoryTab";
import ResultsView from "./components/ResultsView";

export default function App() {
  // Navigation & Core flows
  const [activeTab, setActiveTab] = useState<"Paciente" | "Escáner" | "Voz" | "Historial">("Paciente");
  const [currentView, setCurrentView] = useState<"main" | "results">("main");
  
  // Connection states (Toggle with AI models vs Offline local catalog)
  const [isOnline, setIsOnline] = useState<boolean>(true);
  const [onlineConsultationsLeft, setOnlineConsultationsLeft] = useState<number>(3);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string>("");

  // Patient Profiling
  const [profile, setProfile] = useState<PatientProfile>({
    name: "",
    diagnosis: "Hipertensión Arterial",
    selectedMeds: []
  });

  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [historyList, setHistoryList] = useState<HistoryEntry[]>([]);

  // Load configuration and history on init
  useEffect(() => {
    try {
      const savedHistory = localStorage.getItem("vitalmayor_history_pro");
      if (savedHistory) {
        setHistoryList(JSON.parse(savedHistory));
      }
      const savedProfile = localStorage.getItem("vitalmayor_profile_pro");
      if (savedProfile) {
        setProfile(JSON.parse(savedProfile));
      }
      const savedConsults = localStorage.getItem("vitalmayor_consults_pro");
      if (savedConsults) {
        setOnlineConsultationsLeft(parseInt(savedConsults, 10));
      }
    } catch (e) {
      console.error("Error reading from localStorage", e);
    }
  }, []);

  // Save history to disk on change
  const saveHistory = (newList: HistoryEntry[]) => {
    setHistoryList(newList);
    localStorage.setItem("vitalmayor_history_pro", JSON.stringify(newList));
  };

  // Save profile state to disk
  useEffect(() => {
    localStorage.setItem("vitalmayor_profile_pro", JSON.stringify(profile));
  }, [profile]);

  // Main evaluation engine triggers here
  const handleEvaluateMedication = async (medName: string) => {
    if (!medName || medName.trim() === "") return;
    
    setIsAnalyzing(true);
    setErrorMessage("");
    
    const formattedName = medName.trim();

    try {
      // Evaluate offline parameters or fallback triggers
      if (!isOnline || onlineConsultationsLeft <= 0) {
        // Fallback directly to high-fidelity Offline engine
        const localResult = getLocalAnalysis(
          formattedName,
          profile.name,
          profile.diagnosis,
          profile.selectedMeds
        );
        
        // Emulate simple latency for immersive offline execution feedback
        await new Promise(resolve => setTimeout(resolve, 800));
        
        setAnalysisResult({ ...localResult, isAiOptimized: false });
        addToHistory(formattedName, { ...localResult, isAiOptimized: false });
        setCurrentView("results");
      } else {
        // Query server side AI Gemini endpoint
        const response = await fetch("/api/analyze-medication", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            medicationName: formattedName,
            patientName: profile.name,
            diagnosis: profile.diagnosis,
            currentMedications: profile.selectedMeds
          })
        });

        if (!response.ok) {
          throw new Error("Respuesta del servidor no disponible. Ejecutando análisis en modo local alternativo...");
        }

        const data = await response.json();
        const aiResult: AnalysisResult = {
          name: data.name || formattedName,
          safe: data.safe !== undefined ? data.safe : true,
          contraindicated: data.contraindicated !== undefined ? data.contraindicated : false,
          riskSeverity: data.riskSeverity || "low",
          riskExplanation: data.riskExplanation || "Compatible según parámetros consultados.",
          pauta: data.pauta || "Revisar pauta posológica habitual.",
          comida: data.comida || "Sugerido ingerir con abundante líquido.",
          interacciones: data.interacciones || [],
          consejoCuidador: data.consejoCuidador || "Observe al paciente de forma proactiva.",
          isAiOptimized: true
        };

        setAnalysisResult(aiResult);
        addToHistory(formattedName, aiResult);
        
        // Deduct playful online allowance
        const remaining = Math.max(0, onlineConsultationsLeft - 1);
        setOnlineConsultationsLeft(remaining);
        localStorage.setItem("vitalmayor_consults_pro", remaining.toString());
        
        setCurrentView("results");
      }
    } catch (err: any) {
      console.warn("Server clinical AI analysis failed, falling back to local dataset safely:", err);
      
      // Notify caregiver that we switched safely to offline mode
      setErrorMessage("No pudimos conectar con el servidor clínico. Analizando con la base de datos local...");
      
      // Fallback
      const localResult = getLocalAnalysis(
        formattedName,
        profile.name,
        profile.diagnosis,
        profile.selectedMeds
      );
      
      setAnalysisResult({ ...localResult, isAiOptimized: false });
      addToHistory(formattedName, { ...localResult, isAiOptimized: false });
      setCurrentView("results");
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Helper: registers structured consultation record
  const addToHistory = (targetMedName: string, resultObj: AnalysisResult) => {
    const now = new Date();
    const formattedTimestamp = now.toLocaleString("es-ES", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });

    const newEntry: HistoryEntry = {
      id: Math.random().toString(36).substring(2, 9),
      timestamp: formattedTimestamp,
      patientName: profile.name || "Paciente Mayor",
      diagnosis: profile.diagnosis,
      medicationName: targetMedName,
      result: resultObj
    };

    saveHistory([newEntry, ...historyList]);
  };

  // Appends analyzed medication directly to current profile as habitual treatment
  const handleAddMedicationToProfile = (medName: string) => {
    if (!profile.selectedMeds.includes(medName)) {
      setProfile(prev => ({
        ...prev,
        selectedMeds: [...prev.selectedMeds, medName]
      }));
    }
  };

  // Clear memory
  const handleClearHistory = () => {
    if (window.confirm("¿Seguro que desea depurar todo el historial de interacciones locales? Esto no se puede deshacer.")) {
      saveHistory([]);
    }
  };

  // Delete single memory item
  const handleDeleteHistoryEntry = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    saveHistory(historyList.filter(item => item.id !== id));
  };

  const isAlreadyAdded = (name: string): boolean => {
    return profile.selectedMeds.some(m => m.toLowerCase() === name.toLowerCase());
  };

  return (
    <div className="flex flex-col min-h-screen font-sans bg-[#f8fafc] text-slate-800">
      <Header
        isOnline={isOnline}
        setIsOnline={(val) => {
          setIsOnline(val);
          setErrorMessage("");
        }}
        onlineConsultationsLeft={onlineConsultationsLeft}
      />

      {currentView === "main" ? (
        <div className="flex-1 pb-24 pt-20">
          {/* Main Visual Wave banner */}
          <section className="bg-teal-700 text-white rounded-b-[2.5rem] pt-6 pb-12 px-4 shadow-xl flex flex-col items-center text-center relative z-0">
            <div className="w-14 h-14 bg-white/10 rounded-full flex items-center justify-center mb-3 backdrop-blur-sm animate-pulse">
              <span className="material-symbols-outlined text-2xl text-teal-200" style={{ fontVariationSettings: "'FILL' 1" }}>
                pill
              </span>
            </div>
            
            <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight">VitalMayor Pro</h1>
            <p className="text-xs text-teal-100 font-medium max-w-md mx-auto mt-1 leading-normal">
              Asistente clínico inteligente creado para acompañar en la administración y compatibilidad de medicamentos en personas mayores.
            </p>

            <div className="mt-4 flex flex-wrap gap-2 justify-center items-center">
              <div className="bg-white/15 backdrop-blur-md px-3.5 py-1.5 rounded-xl flex items-center gap-1.5 text-[11px] font-bold">
                <span className="material-symbols-outlined text-xs text-teal-200">wifi_off</span>
                <span>Análisis Local Activo</span>
              </div>

              {isOnline && onlineConsultationsLeft > 0 ? (
                <div className="bg-orange-500/80 backdrop-blur-md px-3.5 py-1.5 rounded-xl flex items-center gap-1.5 text-[11px] font-bold border border-orange-450/30 text-orange-50">
                  <Sparkles className="w-3.5 h-3.5 text-orange-200" />
                  <span>IA Gemini conectada ({onlineConsultationsLeft} libres)</span>
                </div>
              ) : (
                <div className="bg-slate-700/65 backdrop-blur-md px-3.5 py-1.5 rounded-xl flex items-center gap-1.5 text-[11px] font-bold text-slate-350">
                  <span className="material-symbols-outlined text-xs">cloud_off</span>
                  <span>Modo básico sin IA</span>
                </div>
              )}
            </div>
          </section>

          {/* Quick Consultation Badge Card */}
          <div className="mx-4 -mt-5 relative z-10 max-w-2xl md:mx-auto">
            <div className="bg-white rounded-2xl p-4.5 shadow-lg border border-slate-150/80 flex justify-between items-center">
              <div className="flex items-center gap-2 text-teal-800">
                <Sparkles className="w-4 h-4 text-teal-600 fill-teal-100/10" />
                <span className="text-xs font-bold tracking-tight">Consultas con IA de Gemini</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setOnlineConsultationsLeft(3);
                    localStorage.setItem("vitalmayor_consults_pro", "3");
                  }}
                  className="text-[10px] uppercase font-bold text-teal-700 hover:text-teal-900 px-2 py-1 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
                  title="Recargar consultas para pruebas"
                >
                  Recargar
                </button>
                <div className="bg-teal-750 text-white text-[10px] font-bold px-3 py-1.5 rounded-full shadow-sm">
                  {onlineConsultationsLeft} de 3
                </div>
              </div>
            </div>
          </div>

          {/* Content Space with responsive grids */}
          <main className="max-w-2xl mx-auto px-4 mt-6">
            {/* Transient Alert Bar */}
            {errorMessage && (
              <div className="mb-4 bg-teal-50 border border-teal-150 rounded-xl p-3 flex items-center gap-2 text-teal-800 text-xs font-bold shadow-sm animate-fade-in">
                <span className="material-symbols-outlined text-sm animate-spin text-teal-600">refresh</span>
                {errorMessage}
              </div>
            )}

            {/* Displaying Loading screen overlay during active AI analyze */}
            {isAnalyzing ? (
              <section className="bg-white rounded-2xl p-8 shadow-lg border border-slate-100/85 text-center min-h-[280px] flex flex-col items-center justify-center space-y-4 animate-pulse">
                <div className="w-14 h-14 bg-teal-50 border border-teal-105 rounded-full flex items-center justify-center text-teal-700">
                  <span className="material-symbols-outlined text-2xl animate-spin">refresh</span>
                </div>
                <div>
                  <h3 className="text-teal-900 font-extrabold text-base">Procesando con Inteligencia de VitalMayor Pro</h3>
                  <p className="text-xs text-slate-400 font-semibold max-w-sm mx-auto mt-1 leading-relaxed">
                    Evaluando contraindicaciones, dosis seguras, interacciones cruzadas con medicación anterior y comida...
                  </p>
                </div>
              </section>
            ) : (
              <>
                {/* Responsive View Tabs */}
                {activeTab === "Paciente" && (
                  <PatientTab
                    profile={profile}
                    setProfile={setProfile}
                    onSearch={handleEvaluateMedication}
                    isOnline={isOnline && onlineConsultationsLeft > 0}
                    isAnalyzing={isAnalyzing}
                  />
                )}

                {activeTab === "Escáner" && (
                  <ScannerTab
                    onScanResult={handleEvaluateMedication}
                    isOnline={isOnline && onlineConsultationsLeft > 0}
                  />
                )}

                {activeTab === "Voz" && (
                  <VoiceTab onVoiceResult={handleEvaluateMedication} />
                )}

                {activeTab === "Historial" && (
                  <HistoryTab
                    historyList={historyList}
                    onSelectEntry={(entry) => {
                      setAnalysisResult(entry.result);
                      setProfile({
                        name: entry.patientName,
                        diagnosis: entry.diagnosis,
                        selectedMeds: profile.selectedMeds // preserve current profile meds for reference
                      });
                      setCurrentView("results");
                    }}
                    onClearHistory={handleClearHistory}
                    onDeleteEntry={handleDeleteHistoryEntry}
                  />
                )}

                {/* Patient Safety Educational disclaimer card */}
                <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-150/80 text-left mt-6 flex items-start gap-3">
                  <Info className="w-5 h-5 text-teal-700 shrink-0 mt-0.5" />
                  <p className="text-[11px] leading-relaxed text-slate-500 font-medium">
                    <strong>Pilar de Responsabilidad Educativa:</strong> Esta aplicación proporciona análisis médicos simulados guiados por algoritmos clínicos locales e Inteligencia Artificial de Gemini. <strong>Nunca</strong> sustituye la instrucción formal del médico tratante, farmacéutico de cabecera ni manuales hospitalarios autorizados de farmacología. Ante riesgos agudos, recurra a urgencias inmediatamente.
                  </p>
                </div>
              </>
            )}
          </main>
        </div>
      ) : (
        /* Results Details Screen */
        analysisResult && (
          <ResultsView
            result={analysisResult}
            profile={profile}
            onBack={() => {
              setCurrentView("main");
              setErrorMessage("");
            }}
            onAddMedication={handleAddMedicationToProfile}
            isMedicationAlreadyAdded={isAlreadyAdded(analysisResult.name)}
          />
        )
      )}

      {/* Primary Fixed Bottom Navigation Dock */}
      {currentView === "main" && (
        <nav className="fixed bottom-0 left-0 w-full z-40 bg-white/95 backdrop-blur-md shadow-[0_-5px_15px_-3px_rgba(15,118,110,0.08)] border-t border-slate-150 px-3 py-2 flex justify-around items-center">
          {[
            { id: "Paciente", icon: "person", label: "Paciente" },
            { id: "Escáner", icon: "barcode_scanner", label: "Escáner" },
            { id: "Voz", icon: "mic", label: "Voz" },
            { id: "Historial", icon: "history", label: "Historial" }
          ].map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                id={`nav-btn-${tab.id}`}
                key={tab.id}
                onClick={() => {
                  if (!isAnalyzing) {
                    setActiveTab(tab.id as any);
                  }
                }}
                className={`flex flex-col items-center justify-center rounded-xl py-2 px-3 md:px-6 transition-all duration-150 cursor-pointer ${
                  isActive
                    ? "bg-teal-700 text-white shadow-md shadow-teal-700/10 scale-102 font-bold"
                    : "text-slate-500 hover:bg-slate-50 hover:text-slate-800 font-semibold"
                }`}
              >
                <span
                  className="material-symbols-outlined text-[22px] leading-none"
                  style={{ fontVariationSettings: isActive ? "'FILL' 1" : "'FILL' 0" }}
                >
                  {tab.icon}
                </span>
                <span className="text-[10px] tracking-wide mt-1 uppercase">{tab.label}</span>
              </button>
            );
          })}
        </nav>
      )}
    </div>
  );
}
