import React from "react";
import { ArrowLeft, AlertOctagon, CheckCircle2, ShieldAlert, Clock, Utensils, MessageSquareHeart, Sparkles, Check } from "lucide-react";
import { AnalysisResult, PatientProfile } from "../types";

interface ResultsViewProps {
  result: AnalysisResult;
  profile: PatientProfile;
  onBack: () => void;
  onAddMedication: (name: string) => void;
  isMedicationAlreadyAdded: boolean;
}

export default function ResultsView({
  result,
  profile,
  onBack,
  onAddMedication,
  isMedicationAlreadyAdded
}: ResultsViewProps) {
  const isContra = result.contraindicated;
  const isMediumRisk = result.riskSeverity === "medium";
  const isHighRisk = result.riskSeverity === "high";

  // Styles based on risk evaluation
  const severityHeaderStyle = isContra
    ? "bg-rose-50 text-rose-900 border-rose-200"
    : isHighRisk || isMediumRisk
    ? "bg-amber-50 text-amber-900 border-amber-200"
    : "bg-emerald-50 text-emerald-950 border-emerald-200";

  const bannerColor = isContra
    ? "from-rose-700 to-rose-900"
    : isHighRisk || isMediumRisk
    ? "from-amber-600 to-amber-800"
    : "from-emerald-600 to-emerald-800";

  return (
    <div className="bg-[#f8fafc] min-h-screen pb-28">
      {/* Search Header */}
      <header className="bg-white sticky top-0 border-b border-slate-200/60 z-40 shadow-sm">
        <div className="flex justify-between items-center px-4 h-16 w-full max-w-3xl mx-auto">
          <div className="flex items-center gap-2">
            <button
              id="back-to-form-btn"
              onClick={onBack}
              className="text-teal-700 hover:bg-slate-100 p-2 rounded-full transition-all flex items-center justify-center active:scale-90"
              title="Volver al formulario"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            <h1 className="text-base font-bold text-slate-800">Resultado del Análisis</h1>
          </div>
          
          {result.isAiOptimized && (
            <span className="text-[10px] font-bold uppercase tracking-wider bg-orange-50 border border-orange-200 text-orange-850 px-2.5 py-1 rounded-xl flex items-center gap-1 shadow-sm">
              <Sparkles className="w-3 h-3 text-orange-600 animate-pulse" />
              IA Gemini Activa
            </span>
          )}
        </div>
      </header>

      <main className="flex-grow p-4 max-w-3xl mx-auto w-full space-y-4 mt-2">
        {/* Semantic Banner Alert */}
        <div className={`bg-gradient-to-r ${bannerColor} text-white rounded-2xl p-6 shadow-md border border-black/5 flex flex-col items-center text-center`}>
          {isContra ? (
            <div className="bg-white/10 p-3 rounded-full mb-3 flex items-center justify-center">
              <AlertOctagon className="w-9 h-9 text-rose-200" />
            </div>
          ) : isHighRisk || isMediumRisk ? (
            <div className="bg-white/10 p-3 rounded-full mb-3 flex items-center justify-center">
              <ShieldAlert className="w-9 h-9 text-amber-200" />
            </div>
          ) : (
            <div className="bg-white/10 p-3 rounded-full mb-3 flex items-center justify-center">
              <CheckCircle2 className="w-9 h-9 text-emerald-250 fill-white/5" />
            </div>
          )}

          <h2 className="text-lg font-bold">
            {isContra
              ? "¡CONTRAINDICACIÓN CRÍTICA DETECTADA!"
              : isHighRisk || isMediumRisk
              ? "¡PRECAUCIÓN Y SEGUIMIENTO EXIGIDO!"
              : "¡COMPATIBILIDAD PERFECTA CONFIRMADA!"}
          </h2>
          <p className="text-sm font-medium mt-1 leading-relaxed opacity-95">
            {isContra
              ? `El uso de este fármaco comporta riesgos perjudiciales con diagnóstico de: ${profile.diagnosis}`
              : `Seguro para el perfil de ${profile.name || "la persona mayor"} bajo las pautas descritas.`}
          </p>
        </div>

        {/* Detailed Risk and Contraindication explanation */}
        <div className={`border rounded-2xl p-5 ${severityHeaderStyle} flex gap-3 shadow-sm`}>
          <div className="shrink-0 mt-0.5">
            {isContra ? (
              <AlertOctagon className="w-5 h-5 text-rose-600" />
            ) : isHighRisk || isMediumRisk ? (
              <ShieldAlert className="w-5 h-5 text-amber-600" />
            ) : (
              <CheckCircle2 className="w-5 h-5 text-emerald-600" />
            )}
          </div>
          <div>
            <h3 className="text-xs font-bold uppercase tracking-widest text-slate-500">Evaluación de Compatibilidad</h3>
            <p className="text-xs font-semibold leading-relaxed mt-1 text-slate-800">
              {result.riskExplanation}
            </p>
          </div>
        </div>

        {/* Medication overview card */}
        <div className="bg-white rounded-2xl p-6 shadow-md border border-slate-100/70 space-y-5">
          <div>
            <h2 className="text-xl font-bold text-teal-950">{result.name}</h2>
            <p className="text-xs font-medium text-slate-500 mt-1 leading-relaxed">{result.subtitle}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Pauta */}
            <div className="bg-slate-50 rounded-xl p-4 flex items-start gap-3 border border-slate-100">
              <div className="bg-teal-50 text-teal-700 rounded-lg p-2 flex items-center justify-center shrink-0">
                <Clock className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[10px] font-bold text-teal-800 uppercase tracking-widest">Pauta & Horario Recomendado</p>
                <p className="text-xs text-slate-800 mt-1 font-medium leading-relaxed">{result.pauta}</p>
              </div>
            </div>

            {/* Alimentación */}
            <div className="bg-slate-50 rounded-xl p-4 flex items-start gap-3 border border-slate-100">
              <div className="bg-amber-100 text-amber-800 rounded-lg p-2 flex items-center justify-center shrink-0">
                <Utensils className="w-5 h-5" />
              </div>
              <div>
                <p className="text-[10px] font-bold text-amber-900 uppercase tracking-widest">Advertencias de Alimentación</p>
                <p className="text-xs text-slate-800 mt-1 font-medium leading-relaxed">{result.comida}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Drug Interactions with Habitual Treatment Card */}
        {result.interacciones && result.interacciones.length > 0 && (
          <div className="bg-white rounded-2xl p-6 shadow-md border border-slate-100/70">
            <h3 className="text-xs font-bold uppercase tracking-widest text-slate-500 mb-3.5">
              Interacciones con su tratamiento habitual ({result.interacciones.length})
            </h3>
            <div className="space-y-3">
              {result.interacciones.map((inter, idx) => {
                const isHigh = inter.severity === "high";
                const isMed = inter.severity === "medium";
                return (
                  <div
                    key={`inter-${idx}`}
                    className={`border rounded-xl p-3.5 flex items-start gap-3 ${
                      isHigh
                        ? "bg-rose-50 border-rose-200/55"
                        : isMed
                        ? "bg-amber-5 border-amber-200/55"
                        : "bg-slate-50 border-slate-100"
                    }`}
                  >
                    <div className="shrink-0 mt-0.5">
                      {isHigh ? (
                        <AlertOctagon className="w-4 h-4 text-rose-600" />
                      ) : (
                        <ShieldAlert className="w-4 h-4 text-amber-500" />
                      )}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-900">{inter.medication}</span>
                        <span className={`text-[9px] font-bold uppercase px-1.5 py-0.2 rounded ${
                          isHigh
                            ? "bg-rose-100 text-rose-800"
                            : "bg-amber-100 text-amber-800"
                        }`}>
                          {isHigh ? "Riesgo Alto" : "Riesgo Moderado"}
                        </span>
                      </div>
                      <p className="text-xs font-medium text-slate-700 leading-normal mt-1.5">
                        {inter.explanation}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Caregiver Tips */}
        <div className="bg-teal-50/50 border border-teal-100/60 rounded-2xl p-5 shadow-sm space-y-2">
          <h4 className="text-xs font-bold uppercase tracking-widest text-teal-800 flex items-center gap-1.5">
            <MessageSquareHeart className="w-5 h-5 text-teal-700" />
            Consejo Clínico para Cuidadores de VitalMayor
          </h4>
          <p className="text-xs font-medium text-slate-700 leading-relaxed italic pl-1">
            "{result.consejoCuidador}"
          </p>
        </div>
      </main>

      {/* Persistent Bottom Controls */}
      <div className="fixed bottom-0 left-0 w-full p-4 bg-white/90 backdrop-blur-md border-t border-slate-200 z-40 flex gap-3 max-w-3xl mx-auto left-1/2 -translate-x-1/2 rounded-t-2xl shadow-lg">
        <button
          id="results-back-btn"
          onClick={onBack}
          className="bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-bold px-6 py-4 rounded-xl transition-all flex-1 text-center justify-center flex items-center active:scale-95 cursor-pointer shadow-sm"
        >
          Volver
        </button>

        {!isContra && (
          <button
            id="add-to-habitual-btn"
            onClick={() => onAddMedication(result.name)}
            disabled={isMedicationAlreadyAdded}
            className={`text-sm font-bold px-6 py-4 rounded-xl transition-all flex-1 text-center justify-center flex items-center gap-2 shadow-md active:scale-95 ${
              isMedicationAlreadyAdded
                ? "bg-emerald-50 border border-emerald-150 text-emerald-850 cursor-not-allowed"
                : "bg-teal-700 hover:bg-teal-800 text-white cursor-pointer"
            }`}
          >
            {isMedicationAlreadyAdded ? (
              <>
                <Check className="w-4 h-4 text-emerald-600" />
                Agregado
              </>
            ) : (
              <>
                Agregar a Habitual
              </>
            )}
          </button>
        )}
      </div>
    </div>
  );
}
