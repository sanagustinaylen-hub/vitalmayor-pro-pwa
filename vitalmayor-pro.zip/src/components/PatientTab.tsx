import React, { useState } from "react";
import { User, Activity, Heart, Pill, Search, Send, Sparkles } from "lucide-react";
import { PatientProfile } from "../types";
import { medicationsList } from "../clinicalDB";

interface PatientTabProps {
  profile: PatientProfile;
  setProfile: React.Dispatch<React.SetStateAction<PatientProfile>>;
  onSearch: (medName: string) => void;
  isOnline: boolean;
  isAnalyzing: boolean;
}

export default function PatientTab({
  profile,
  setProfile,
  onSearch,
  isOnline,
  isAnalyzing
}: PatientTabProps) {
  const [searchQuery, setSearchQuery] = useState("");

  const toggleMed = (med: string) => {
    setProfile(prev => {
      const alreadyHas = prev.selectedMeds.includes(med);
      const updated = alreadyHas
        ? prev.selectedMeds.filter(m => m !== med)
        : [...prev.selectedMeds, med];
      return { ...prev, selectedMeds: updated };
    });
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      onSearch(searchQuery.trim());
    }
  };

  return (
    <div className="space-y-6">
      {/* Patient Profile Card */}
      <section className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100/80 transition-all duration-300">
        <h2 className="flex items-center gap-2 text-teal-800 text-lg font-bold mb-4">
          <User className="w-5 h-5 text-teal-700 fill-teal-100/10" />
          Perfil de Paciente Mayor
        </h2>
        
        <div className="space-y-4">
          {/* Patient Name */}
          <div>
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5 pl-0.5">
              Nombre de la Persona Mayor o Familiar
            </label>
            <div className="relative">
              <input
                id="patient-name-input"
                value={profile.name}
                onChange={(e) => setProfile(prev => ({ ...prev, name: e.target.value }))}
                className="w-full border border-teal-600/30 rounded-xl p-3 bg-slate-50/50 focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600 outline-none transition-all placeholder:text-slate-400 text-slate-850 font-medium"
                placeholder="Ej. Carmen Gómez"
                type="text"
              />
            </div>
          </div>

          {/* Primary Diagnosis */}
          <div>
            <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1.5 pl-0.5">
              <Activity className="w-3.5 h-3.5 text-teal-600" />
              Diagnóstico de Alerta Principal
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-rose-600">
                <Heart className="w-4 h-4 fill-rose-500/10" />
              </div>
              <select
                id="diagnosis-select"
                value={profile.diagnosis}
                onChange={(e) => setProfile(prev => ({ ...prev, diagnosis: e.target.value }))}
                className="w-full border border-slate-200/80 rounded-xl p-3 pl-10 bg-slate-50/50 appearance-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-600 outline-none text-slate-800 font-medium cursor-pointer"
              >
                <option value="Hipertensión Arterial">Hipertensión Arterial</option>
                <option value="Diabetes Mellitus">Diabetes Mellitus</option>
                <option value="Artrosis">Artrosis</option>
                <option value="Insuficiencia Renal">Insuficiencia Renal</option>
                <option value="Ninguno">Ninguno de los anteriores</option>
              </select>
              <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-slate-400">
                <span className="material-symbols-outlined text-sm">expand_more</span>
              </div>
            </div>
          </div>

          {/* Habitual Medication list toggles */}
          <div>
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2 pl-0.5">
              Medicamentos Habituales actuales ({profile.selectedMeds.length})
            </label>
            <div className="flex flex-wrap gap-1.5">
              {medicationsList.map(med => {
                const isActive = profile.selectedMeds.includes(med);
                return (
                  <button
                    id={`med-chip-${med}`}
                    key={med}
                    type="button"
                    onClick={() => toggleMed(med)}
                    className={`text-xs font-semibold px-3 py-2 rounded-xl transition-all active:scale-95 flex items-center gap-1 ${
                      isActive
                        ? "bg-teal-700 text-white shadow-sm ring-1 ring-teal-800"
                        : "bg-slate-150/70 text-slate-600 hover:bg-slate-200/80 hover:text-slate-800"
                    }`}
                  >
                    <Pill className={`w-3 h-3 ${isActive ? "text-teal-200 fill-teal-100/10" : "text-slate-400"}`} />
                    {med}
                  </button>
                );
              })}
            </div>
            <p className="text-[11px] text-slate-400 mt-2 font-medium leading-normal italic pl-0.5">
              Marque los fármacos que ya consume el paciente para buscar interacciones nocivas con la nueva receta.
            </p>
          </div>
        </div>
      </section>

      {/* Quick Search Card */}
      <section className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100/80 transition-all duration-300">
        <h2 className="flex items-center gap-2 text-teal-800 text-lg font-bold mb-3">
          <Search className="w-5 h-5 text-teal-700" />
          Búsqueda de Nuevo Medicamento
        </h2>
        <p className="text-xs text-slate-500 mb-4 font-medium leading-relaxed">
          Escriba el nombre comercial o principio activo que desea evaluar respecto al perfil del paciente.
        </p>

        <form onSubmit={handleSearchSubmit} className="flex gap-2">
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-400">
              <Search className="w-4 h-4" />
            </div>
            <input
              id="med-search-input"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full border-none bg-slate-100 rounded-xl py-3.5 pl-10 pr-4 focus:ring-2 focus:ring-teal-500 outline-none text-slate-800 placeholder:text-slate-400 font-medium text-sm transition-shadow"
              placeholder="Ej. Omeprazol, Losartán, Aspirina..."
              type="text"
              disabled={isAnalyzing}
            />
          </div>
          <button
            id="med-search-btn"
            type="submit"
            disabled={isAnalyzing || !searchQuery.trim()}
            className={`px-5 py-3.5 rounded-xl font-semibold flex items-center gap-1.5 transition-all text-sm active:scale-95 shadow-md ${
              searchQuery.trim()
                ? "bg-teal-700 hover:bg-teal-800 text-white cursor-pointer"
                : "bg-slate-200 text-slate-400 cursor-not-allowed shadow-none"
            }`}
          >
            {isAnalyzing ? (
              <span className="material-symbols-outlined text-sm animate-spin">refresh</span>
            ) : isOnline ? (
              <Sparkles className="w-4 h-4 text-teal-200" />
            ) : (
              <Send className="w-4 h-4" />
            )}
            Evaluar
          </button>
        </form>
      </section>
    </div>
  );
}
