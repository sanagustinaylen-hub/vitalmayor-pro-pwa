import React from "react";
import { History, Trash2, Calendar, User, Eye, Sparkles } from "lucide-react";
import { HistoryEntry } from "../types";

interface HistoryTabProps {
  historyList: HistoryEntry[];
  onSelectEntry: (entry: HistoryEntry) => void;
  onClearHistory: () => void;
  onDeleteEntry: (id: string, e: React.MouseEvent) => void;
}

export default function HistoryTab({
  historyList,
  onSelectEntry,
  onClearHistory,
  onDeleteEntry
}: HistoryTabProps) {
  if (historyList.length === 0) {
    return (
      <section className="bg-white rounded-2xl p-8 shadow-lg border border-slate-100/80 text-center transition-all duration-300">
        <div className="flex flex-col items-center py-8">
          <div className="w-16 h-16 bg-slate-50 border border-slate-150 rounded-full flex items-center justify-center text-slate-400 mb-4">
            <History className="w-8 h-8" />
          </div>
          <h3 className="text-slate-800 font-bold text-base">No hay consultas recientes</h3>
          <p className="text-xs text-slate-400 font-medium max-w-sm mx-auto mt-1 leading-normal">
            Las evaluaciones clínicas que realice quedarían registradas temporalmente en esta memoria local para acceso veloz.
          </p>
        </div>
      </section>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center px-1">
        <h2 className="text-sm font-bold text-slate-600 uppercase tracking-widest flex items-center gap-1.5">
          <History className="w-4 h-4 text-slate-500" />
          Memoria de Interacciones ({historyList.length})
        </h2>
        <button
          id="clear-all-history-btn"
          onClick={onClearHistory}
          className="text-xs font-semibold text-rose-600 hover:text-rose-700 active:scale-95 transition-all py-1 px-2 rounded-lg hover:bg-rose-50"
        >
          Borrar todo
        </button>
      </div>

      <div className="space-y-3">
        {historyList.map((entry) => {
          const isContra = entry.result.contraindicated;
          const isAi = entry.result.isAiOptimized;
          return (
            <div
              id={`history-item-${entry.id}`}
              key={entry.id}
              onClick={() => onSelectEntry(entry)}
              className="bg-white border border-slate-100 rounded-2xl p-4 shadow-sm hover:shadow-md hover:border-slate-200 transition-all cursor-pointer flex justify-between items-start group"
            >
              <div className="space-y-1.5 flex-1 pr-4">
                <div className="flex items-center gap-2">
                  <span className={`text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-md ${
                    isContra
                      ? "bg-rose-50 text-rose-800 border border-rose-200/55"
                      : "bg-teal-50 text-teal-800 border border-teal-200/55"
                  }`}>
                    {isContra ? "Contraindicado" : "Seguro / Vigilado"}
                  </span>

                  {isAi && (
                    <span className="text-[10px] uppercase font-bold tracking-wider bg-orange-50 text-orange-850 border border-orange-200/55 px-2 py-0.5 rounded-md flex items-center gap-0.5">
                      <Sparkles className="w-2.5 h-2.5 text-orange-700" />
                      Gemini IA
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-1">
                  <span className="font-bold text-slate-900 group-hover:text-teal-700 text-sm">
                    {entry.result.name}
                  </span>
                  <span className="text-slate-400 font-medium text-xs">para</span>
                  <span className="font-bold text-slate-800 text-sm flex items-center gap-0.5">
                    <User className="w-3.5 h-3.5 text-slate-400 inline" />
                    {entry.patientName || "Paciente sin nombre"}
                  </span>
                </div>

                <div className="flex items-center gap-4 text-[11px] text-slate-450 font-semibold">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    {entry.timestamp}
                  </span>
                  <span>Diagnóstico: {entry.diagnosis}</span>
                </div>
              </div>

              <div className="flex items-center gap-1 bg-slate-50 border border-slate-150 p-1.5 rounded-xl self-center shrink-0">
                <button
                  id={`review-history-item-btn-${entry.id}`}
                  className="text-slate-600 hover:text-teal-700 hover:bg-white p-2 rounded-lg transition-colors"
                  title="Ver Análisis Completo"
                >
                  <Eye className="w-4 h-4" />
                </button>
                <button
                  id={`delete-history-item-btn-${entry.id}`}
                  onClick={(e) => onDeleteEntry(entry.id, e)}
                  className="text-slate-400 hover:text-rose-600 hover:bg-white p-2 rounded-lg transition-colors"
                  title="Eliminar Registro"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
