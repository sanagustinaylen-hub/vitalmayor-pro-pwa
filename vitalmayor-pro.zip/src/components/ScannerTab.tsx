import React, { useRef, useState } from "react";
import { Camera, Image as ImageIcon, CheckCircle, Sparkles, AlertTriangle, Play } from "lucide-react";
import { createWorker } from "tesseract.js";

interface ScannerTabProps {
  onScanResult: (detectedName: string) => void;
  isOnline: boolean;
}

export default function ScannerTab({ onScanResult, isOnline }: ScannerTabProps) {
  const [status, setStatus] = useState<"idle" | "reading" | "success" | "error">("idle");
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [log, setLog] = useState<string>("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  // High-performance image analyzer (Online via Gemini or Offline via Tesseract)
  const analyzeImage = async (imageSrc: string) => {
    setStatus("reading");
    setLog(isOnline ? "Enviando empaque a Gemini AI..." : "Inicializando lector local Tesseract...");

    try {
      if (isOnline) {
        // Online Gemini AI Vision Scan
        const response = await fetch("/api/ocr-scan", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ base64Image: imageSrc })
        });
        const data = await response.json();
        
        if (response.ok && data.medicationName && data.medicationName !== "No detectado") {
          const matched = data.medicationName;
          setLog(`Gemini detectó: "${matched}"`);
          setStatus("success");
          setTimeout(() => {
            onScanResult(matched);
            setImagePreview(null);
            setStatus("idle");
          }, 1200);
        } else {
          throw new Error("No pudimos reconocer el nombre del medicamento de forma nítida.");
        }
      } else {
        // Offline Tesseract OCR
        const worker = await createWorker("spa");
        setLog("Analizando letras y etiquetas del empaque...");
        const ret = await worker.recognize(imageSrc);
        const extractedText = ret.data.text;
        await worker.terminate();

        setLog("Buscando palabras clave en base local...");
        // Match words
        const keywords = ["omeprazol", "losartan", "ibuprofeno", "metformina", "atorvastatina", "levotiroxina", "enalapril", "paracetamol", "furosemida", "warfarina"];
        const cleanText = extractedText.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
        
        let foundWord: string | null = null;
        for (const word of keywords) {
          if (cleanText.includes(word)) {
            foundWord = word;
            break;
          }
        }

        if (foundWord) {
          // Capitalize correctly
          const capitalized = foundWord.charAt(0).toUpperCase() + foundWord.slice(1);
          setLog(`Letras locales OCR detectaron: "${capitalized}"`);
          setStatus("success");
          setTimeout(() => {
            onScanResult(capitalized);
            setImagePreview(null);
            setStatus("idle");
          }, 1200);
        } else {
          throw new Error("El texto detectado no coincide con nuestro catálogo local de emergencia. Intente buscar por teclado de forma rápida.");
        }
      }
    } catch (err: any) {
      console.error(err);
      setStatus("error");
      setLog(err.message || "Error al leer la imagen. Intente de nuevo con mejor iluminación.");
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        setImagePreview(base64);
        analyzeImage(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  // Triggers simulator clicks for fast testing inside sandbox environment
  const handleSimulateScan = (medName: string) => {
    setStatus("reading");
    setImagePreview("MOCK_PREVIEW");
    setLog(`Simulando escaneo de caja comercial de ${medName}...`);
    setTimeout(() => {
      setStatus("success");
      setLog(`¡${medName} leído y autenticado con éxito!`);
      setTimeout(() => {
        onScanResult(medName);
        setImagePreview(null);
        setStatus("idle");
      }, 1000);
    }, 1500);
  };

  return (
    <div className="space-y-6">
      {/* Smart Scanner Panel */}
      <section className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100/80 transition-all duration-300">
        <h2 className="flex items-center gap-2 text-teal-800 text-lg font-bold mb-2">
          <Camera className="w-5 h-5 text-teal-700" />
          Escáner de Empaques con Cámara
        </h2>
        <p className="text-xs text-slate-500 mb-6 font-medium leading-relaxed">
          Fotografíe la caja o prospecto del medicamento. La IA de VitalMayor analizará las letras del empaque para identificar el producto al instante.
        </p>

        {/* Action Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
          <input
            id="scanner-camera-input"
            type="file"
            accept="image/*"
            capture="environment"
            className="hidden"
            ref={cameraInputRef}
            onChange={handleFileChange}
          />
          <button
            id="camera-scan-btn"
            onClick={() => cameraInputRef.current?.click()}
            className="bg-teal-700 hover:bg-teal-800 text-white rounded-xl py-3.5 px-4 flex justify-center items-center gap-2.5 text-sm font-semibold shadow-md active:scale-95 transition-all"
          >
            <Camera className="w-5 h-5" />
            Tomar Foto de Caja
          </button>

          <input
            id="scanner-file-input"
            type="file"
            accept="image/*"
            className="hidden"
            ref={fileInputRef}
            onChange={handleFileChange}
          />
          <button
            id="gallery-scan-btn"
            onClick={() => fileInputRef.current?.click()}
            className="bg-slate-100 hover:bg-slate-200/80 text-slate-700 rounded-xl py-3.5 px-4 flex justify-center items-center gap-2.5 text-sm font-semibold shadow-sm active:scale-95 transition-all"
          >
            <ImageIcon className="w-5 h-5 text-slate-500" />
            Subir de Galería
          </button>
        </div>

        {/* Scan Status View */}
        {imagePreview && (
          <div className="relative border border-slate-200 rounded-2xl overflow-hidden bg-slate-950 flex flex-col items-center justify-center p-6 min-h-[220px]">
            {/* Scan animation */}
            {status === "reading" && <div className="animate-scan" />}

            {imagePreview !== "MOCK_PREVIEW" ? (
              <img
                src={imagePreview}
                alt="Medication package preview"
                className="max-h-48 object-contain rounded-lg opacity-60 mb-4"
              />
            ) : (
              <div className="flex flex-col items-center text-teal-400 p-8 space-y-2 animate-pulse">
                <Camera className="w-12 h-12" />
                <span className="text-xs font-bold uppercase tracking-wider">Simulación Óptica de Cámara</span>
              </div>
            )}

            <div className="text-center z-10">
              {status === "reading" && (
                <div className="text-teal-400 font-semibold text-sm flex items-center justify-center gap-2 animate-pulse">
                  <span className="material-symbols-outlined animate-spin text-lg">refresh</span>
                  {log}
                </div>
              )}
              {status === "success" && (
                <div className="text-teal-450 font-bold text-sm flex items-center justify-center gap-1.5">
                  <CheckCircle className="w-5 h-5 text-brand-teal-light" />
                  {log}
                </div>
              )}
              {status === "error" && (
                <div className="text-rose-450 font-semibold text-sm flex items-center justify-center gap-1.5 p-2 bg-rose-500/10 rounded-xl border border-rose-500/20 max-w-md mx-auto">
                  <AlertTriangle className="w-5 h-5 text-rose-500" />
                  {log}
                </div>
              )}
            </div>
          </div>
        )}
      </section>

      {/* Simulator Sandbox Testing */}
      <section className="bg-slate-50 border border-slate-200 rounded-2xl p-6 transition-all duration-300">
        <h3 className="flex items-center gap-1.5 text-slate-800 text-sm font-bold mb-2">
          <Sparkles className="w-4 h-4 text-teal-600 fill-teal-100/10" />
          Probeta de Simulación Rápida (Sandbox Testing)
        </h3>
        <p className="text-[11px] text-slate-500 mb-4 font-medium leading-relaxed">
          Ya que no podemos ver su empaque médico físico a través de este entorno virtual, haga clic en cualquier muestra para activar la lectura automática del fármaco:
        </p>

        <div className="grid grid-cols-2 gap-2">
          {[
            { tag: "Metformina", size: "850 mg", desc: "Caja Roja Glucosa" },
            { tag: "Ibuprofeno", size: "600 mg", desc: "Blíster Rosa Dolores" },
            { tag: "Omeprazol", size: "20 mg", desc: "Frasco Gástrico" },
            { tag: "Atorvastatina", size: "10 mg", desc: "Caja Colesterol" }
          ].map((item) => (
            <button
              id={`simulate-btn-${item.tag}`}
              key={item.tag}
              onClick={() => handleSimulateScan(item.tag)}
              className="text-left bg-white border border-slate-200 rounded-xl p-3 hover:border-teal-500 hover:shadow-sm active:scale-[0.98] transition-all flex justify-between items-center group cursor-pointer"
            >
              <div>
                <p className="text-xs font-bold text-teal-900 group-hover:text-teal-700">{item.tag}</p>
                <p className="text-[10px] text-slate-400 font-semibold">{item.desc} · {item.size}</p>
              </div>
              <Play className="w-3.5 h-3.5 text-slate-350 fill-slate-300 group-hover:text-teal-600 group-hover:fill-teal-50" />
            </button>
          ))}
        </div>
      </section>
    </div>
  );
}
