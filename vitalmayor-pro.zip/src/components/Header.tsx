import React from "react";
import { Shield, Cloud, CloudOff, User } from "lucide-react";

interface HeaderProps {
  isOnline: boolean;
  setIsOnline: (val: boolean) => void;
  onlineConsultationsLeft: number;
}

export default function Header({ isOnline, setIsOnline, onlineConsultationsLeft }: HeaderProps) {
  return (
    <header className="fixed top-0 left-0 w-full z-50 flex justify-between items-center px-4 md:px-8 h-16 bg-white/85 dark:bg-slate-900/85 backdrop-blur-md border-b border-slate-200/60 dark:border-slate-800/60 shadow-sm transition-all duration-300">
      <div className="flex items-center gap-2">
        <div className="bg-teal-700 text-white p-1.5 rounded-lg flex items-center justify-center">
          <Shield className="w-5 h-5 fill-teal-100/20" />
        </div>
        <div className="flex flex-col">
          <span className="text-lg font-bold text-teal-800 dark:text-teal-400 tracking-tight leading-none">VitalMayor Pro</span>
          <span className="text-[10px] text-slate-500 font-medium tracking-wide uppercase mt-0.5">Asistente Clínico</span>
        </div>
      </div>

      <div className="flex items-center gap-3">
        {/* Connection Toggle Switch */}
        <button
          onClick={() => setIsOnline(!isOnline)}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border transition-all text-xs font-semibold shadow-sm active:scale-95 ${
            isOnline
              ? "bg-teal-50 border-teal-200 text-teal-800 hover:bg-teal-100"
              : "bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100"
          }`}
          title={isOnline ? "Cambiar a Modo Local (Sin dependencias)" : "Activar IA de Gemini (Requiere clave)"}
        >
          {isOnline ? (
            <>
              <Cloud className="w-4 h-4 text-teal-600 animate-pulse" />
              <span className="hidden sm:inline">Modo Online (IA)</span>
              <span className="sm:hidden">Online</span>
              <span className="text-[10px] bg-teal-200/65 text-teal-900 px-1.5 py-0.2 rounded-full font-bold ml-1">
                {onlineConsultationsLeft}
              </span>
            </>
          ) : (
            <>
              <CloudOff className="w-4 h-4 text-slate-600" />
              <span className="hidden sm:inline">Modo Local (100% Offline)</span>
              <span className="sm:hidden">Local</span>
            </>
          )}
        </button>

        {/* User Profile */}
        <div className="w-9 h-9 rounded-full bg-teal-50 border border-teal-100 text-teal-700 flex items-center justify-center cursor-pointer hover:bg-teal-100 transition-colors">
          <User className="w-4 h-4 fill-teal-700/10" />
        </div>
      </div>
    </header>
  );
}
