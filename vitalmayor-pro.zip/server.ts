import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Middleware for parsing JSON requests with higher limits for base64 images
app.use(express.json({ limit: "15mb" }));

// Lazy initializer for GoogleGenAI to meet security & stability guidelines
let aiClient: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      throw new Error("La clave GEMINI_API_KEY no está configurada en la plataforma.");
    }
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// API Route: Analyze Medication Safety with Gemini (Online Assistant Mode)
app.post("/api/analyze-medication", async (req, res) => {
  try {
    const { medicationName, patientName, diagnosis, currentMedications } = req.body;

    if (!medicationName) {
      return res.status(400).json({ error: "Falta el nombre del medicamento." });
    }

    const ai = getAiClient();

    // Create prompt for safety assessment
    const prompt = `Analiza detalladamente la seguridad del medicamento "${medicationName}" para un paciente llamado "${patientName || 'Paciente'}".
Perfil Clínico del Paciente:
- Diagnóstico Principal: ${diagnosis || "Ninguno específico"}
- Medicación Habitual Actual: ${currentMedications && currentMedications.length > 0 ? currentMedications.join(", ") : "Ninguna medicación habitual"}

Determina si "${medicationName}" es seguro, moderado o contraindicado para este paciente con base en su diagnóstico y posibles interacciones farmacológicas severas con su medicación habitual actual.
Explica de manera concisa pero sumamente clara para un cuidador. No uses lenguaje excesivamente técnico e incomprensible; prioriza la pauta práctica, advertencias clave (especialmente con comidas/horarios) e interacciones graves.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: `Eres un asistente de ayuda clínica de VitalMayor Pro diseñado para cuidadores de personas mayores. Tu tarea es analizar la seguridad de un medicamento contra el perfil diagnóstico y farmacológico de un paciente en particular.
Debes devolver una respuesta estructurada estrictamente en formato JSON utilizando el esquema requerido.
Asegúrate de:
1. Evaluar si hay contraindicaciones directas con el diagnóstico especificado (ej. el Ibuprofeno de forma general está contraindicado o requiere suma precaución en personas con Hipertensión Arterial o Insuficiencia Renal debido al riesgo de elevar la presión y sobrecarga renal).
2. Evaluar interacciones graves o de precaución entre el nuevo medicamento y la medicación habitual actual del paciente (ej. mezclar Ibuprofeno con Warfarina dispara el riesgo de sangrados severos; o mezclar diuréticos con antihipertensivos requiere vigilar la presión para evitar caídas).
3. Entregar una pauta clara (ej. "Tomar antes del desayuno", "No tomar junto con lácteos" o "Tomar preferentemente por la noche").
4. Mantener un tono servicial, claro, calmado pero alerta si hay riesgos altos. Todo debe estar redactado en español clínico comprensible para un cuidador promedio.`,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: [
            "name",
            "safe",
            "contraindicated",
            "riskSeverity",
            "riskExplanation",
            "pauta",
            "comida",
            "interacciones",
            "consejoCuidador"
          ],
          properties: {
            name: {
              type: Type.STRING,
              description: "Nombre del medicamento analizado.",
            },
            safe: {
              type: Type.BOOLEAN,
              description: "Indica si el medicamento es seguro y compatible sin contraindicaciones directas ni interacciones severas.",
            },
            contraindicated: {
              type: Type.BOOLEAN,
              description: "Indica si está directamente contraindicado debido al diagnóstico del paciente.",
            },
            riskSeverity: {
              type: Type.STRING,
              description: "Nivel de riesgo estimado para el paciente en su situación actual. Debe ser exactamente: 'low', 'medium' o 'high'.",
            },
            riskExplanation: {
              type: Type.STRING,
              description: "Explicación detallada de por qué existe una contraindicación o riesgo alto en un lenguaje comprensible para cuidadores.",
            },
            pauta: {
              type: Type.STRING,
              description: "Recomendaciones específicas sobre su administración (ej. dosis usual de consulta, tiempo antes de comidas).",
            },
            comida: {
              type: Type.STRING,
              description: "Interacciones relevantes con alimentos (ej. no beber con jugo de pomelo, evitar lácteos con la levotiroxina).",
            },
            interacciones: {
              type: Type.ARRAY,
              description: "Lista de posibles interacciones nocivas específicas detectadas con la medicación habitual actual del paciente.",
              items: {
                type: Type.OBJECT,
                required: ["medication", "severity", "explanation"],
                properties: {
                  medication: {
                    type: Type.STRING,
                    description: "Nombre del fármaco con el cual genera conflicto.",
                  },
                  severity: {
                    type: Type.STRING,
                    description: "Severidad de la interacción: 'low', 'medium' o 'high'.",
                  },
                  explanation: {
                    type: Type.STRING,
                    description: "Consecuencias clínicas y qué debe vigilar el cuidador.",
                  },
                },
              },
            },
            consejoCuidador: {
              type: Type.STRING,
              description: "Un consejo general o frase empática y de soporte enfocada en el cuidador responsable.",
            },
          },
        },
      },
    });

    const parsedJson = JSON.parse(response.text?.trim() || "{}");
    return res.json(parsedJson);
  } catch (error: any) {
    console.error("Error en analyze-medication:", error);
    return res.status(500).json({ error: error.message || "Error al analizar el medicamento." });
  }
});

// API Route: Multi-modal OCR scan of medication box/leaflet using Gemini-3.5-flash
app.post("/api/ocr-scan", async (req, res) => {
  try {
    const { base64Image } = req.body;

    if (!base64Image) {
      return res.status(400).json({ error: "Falta la imagen para el escaneo OCR." });
    }

    const ai = getAiClient();

    // Remove metadata prefix of base64 like "data:image/png;base64," if present
    const cleanBase64 = base64Image.includes(";base64,")
      ? base64Image.split(";base64,")[1]
      : base64Image;

    const mimeType = base64Image.match(/data:([^;]+);/)?.[1] || "image/jpeg";

    const imagePart = {
      inlineData: {
        mimeType: mimeType,
        data: cleanBase64,
      },
    };

    const textPart = {
      text: "Identify the main medication name written on this box, bottle, or medical leaflet. Return ONLY the single main active pharmaceutical ingredient or brand name in Spanish (e.g. 'Losartán', 'Omeprazol', 'Ibuprofeno', 'Metformina', 'Atorvastatina', etc.). If it is something else, write the generic name. Do NOT add sentences or explanations. Return ONLY the name. If no medication can be recognized, respond with exactly: 'No detectado'.",
    };

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: { parts: [imagePart, textPart] },
    });

    const name = response.text?.trim() || "";
    return res.json({ medicationName: name });
  } catch (error: any) {
    console.error("Error en ocr-scan:", error);
    return res.status(500).json({ error: error.message || "Error al procesar la imagen mediante OCR de Gemini." });
  }
});

// Vite or Static file serving setup based on environment
async function initServer() {
  if (process.env.NODE_ENV !== "production") {
    // Development mode
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Production Mode serving compiled static files
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[VitalMayor Pro Server] Running on http://localhost:${PORT} [NODE_ENV=${process.env.NODE_ENV || "development"}]`);
  });
}

initServer().catch((err) => {
  console.error("Error starting VitalMayor Pro Server:", err);
});
